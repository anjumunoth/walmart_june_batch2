import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import "./Menu.css";

export default class Menu extends Component {
  render() {
    return (
      <div>
        <ul>
            <li>
                <Link to="/home">Home</Link>
            </li>
            <li>
                <Link to="/users">Users</Link>
            </li>
            <li>
                <Link to="/contactus">Contact Us</Link>
            </li>
            <li>
                <Link to="/sample">Sample</Link>
            </li>
            
        </ul>
      </div>
    )
  }
}
