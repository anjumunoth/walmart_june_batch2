import React, { Component } from 'react'
import { Route, Switch,Redirect } from "react-router-dom";
import Users from "./Users"
import Home from './Home';
import Sample from './Sample';
import Details from './Details';

export default class MyRoutes extends Component {
    render() {
        return (
            <div>
                <Switch>
                    <Route path="/details/:pId" component={Details}></Route>
                    <Redirect path="/" to="/home" exact ></Redirect>
                    <Route path="/users" component={Users}></Route>
                    <Route path="/home" component={Home}></Route>
                    <Route path="/contactus" render={() => {
                        return (
                            <div> <h1> Contact Us</h1></div>
                        )
                    }}></Route>
                    <Route path="/sample" component={Sample}></Route>
                    <Route render={
                        () => {
                            return (
                                <div>
                                    <h1>Page not found</h1>
                                </div>
                            )
                        }
                    }></Route>
                </Switch>
            </div>
        )
    }
}
