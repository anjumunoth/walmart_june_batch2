import React, { Component } from 'react'

export default class Cart extends Component {
  render() {
    var item=this.props.cartObj;
    return (
      <div>Cart
        {
            Object.keys(item).length === 0 ?<h1>No items in the Cart</h1>:
        <table className='table'>
                <tr>
                    <td>{item.name}</td>
                    <td>{item.quantitySelected}</td>
                    <td>{item.price}</td>
                    
                </tr>
           
        </table>
  }
      </div>
    )
  }
}

/*
Redux 

store -- have a state -- single source of data
reducers -- pure function which can only modify the data(store's state) based on dispatched actions
function productReducers(state,action)
{
    // no random functions
    // no api calls

    newState= state + some modifications based on action
    return newState
}


action -- how to modify the data; object 
random() -- return a random number in the range 0 to 1

function f1(p1,p2)
{
    // pure function ; for the same input params always the same output is got
    return (p1+p2);
}

function f2(p1,p2)
{
    // impure function
    return (p1+p2+ Math.random();)
    //api call to get productsArr
}

f1(10,20);//30
f1(10,20);//30
f2(10,20);//random value b/w 30 and 31; 30.5
f2(10,20);// random value b/w 30 and 31; 30.7
*/
