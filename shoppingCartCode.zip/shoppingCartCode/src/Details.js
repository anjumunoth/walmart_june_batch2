import React, { Component } from 'react'

export default class Details extends Component {
    backEventHandler=()=>{
        this.props.history.goBack();
        // this.props.history.go(-1);
        // this.props.history.push("/home");
    }
  render() {
    console.log("Props in Details component",this.props);
    return (
      <div>Details Component
        <h1>ProductId : {this.props.match.params.pId}</h1>
        <p>
            Product Details:
            {JSON.stringify(this.props.location.state.selectedProduct)}
        </p>
        <input type="button" value="Back" onClick={this.backEventHandler}/>
      </div>
    )
  }
}
