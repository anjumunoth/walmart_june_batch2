import './App.css';
import Header from "./Header";
import Footer from "./Footer";
import Home from './Home';
import Menu from './Menu';
import { BrowserRouter } from 'react-router-dom';
import MyRoutes from './MyRoutes';

function App() {
  return (
    <div>
      <Header></Header>
      <BrowserRouter>
        <Menu></Menu>
        <MyRoutes></MyRoutes>
      </BrowserRouter>
      <Footer></Footer>
    </div>
  );
}

export default App;
//<img src="../public/dosa.jpg" alt="dosa image" />
//webpack
// transpilation and convert to a lower version of js
// minification and uglification
// compression of file according to various standards
// optimise the app size(bundle size)

// parathaImg is better
// 10 images -- src 
// increasing the bundle size(bad) and before the image loads , bundling happens(performance loads)
// public folder -- static resources 

/*
bootstrap
grid
grid -- rows and columns
Each row can have 12 columns
logo -- 4 columns and text -- 8 columns

primary -- blue
danger -- red
warning -- yellow
success -- green
secondary -- grey 
*/
