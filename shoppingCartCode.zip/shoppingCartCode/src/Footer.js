import React,{useState,useEffect} from 'react';

function Footer(props)
{
    console.log("Inside footer");
    const [ctr,setCtr]=useState(0);
    const [emp,setEmp]=useState({empId:101,empName:"sara",salary:45678});

    // setCtr function is going to be used to modify the value of ctr
    // setCtr <-->setState
    // setCtr-- async
    // setCtr -- modify the ctr and rerender(call the entire function again);
    //useState is going to return an array;destructuting and storing in 2 variables   
    // const ctr=useState(0)[0]
    // const setCtr=useState(0)[1]
    // useState -- in built hook ; useState -- maintain the value across the updates 
    // setCtr -- call the function again: 
    // check if the useState is already defined; if defined -- hold the values; if undefined -- initialisation
    // useState -- will maintain the values across updates;

    //useEffect -- lifecycle methods
    // useEffect -- second param -- dependency array -- empty array
    useEffect(()=>{
        // executed only once during the entire lifecycle of component
        // like the constructor/componentDidMount
        console.log("Inside the effect which mimics a constructor");
    },[]);
    useEffect(()=>{
        // componentDidUpdate
        console.log("Inside the effect each time it rerenders");
    });

    useEffect(()=>{
        // send the update to the db
        console.log("Inside the effect each time ctr changes");
    },[ctr]);

    useEffect(()=>{

        // whenever the props and changes and u want to update the state based on changes in the props
    },[props.companyName]);

    // componentWillUnMount
    // destructor -- obj is going to killed and free the memory space
    useEffect(()=>{
        console.log("This is also going to mimic a constructor")
        return (()=>{
            alert("Footer component unmounted");
        })
    },[])

    useEffect(()=>{
        // call to the server
    },[])

    const incrementSalaryEventHandler=()=>{
        //var newEmp={...emp,salary:emp.salary+1000};
        setEmp((prevEmp)=>{
            return ({...prevEmp,salary:prevEmp.salary+1000});
        });
    }
    const incrementEventHandler=()=>{
        console.log("Inside the increment event handler");
        //ctr+=1;
        setCtr(ctr+1);
        //console.log("Counter"+ctr);
    }
    return(
        <div>
            <h1>Footer Component</h1>
            <h2>Counter : {ctr}</h2>
            <h2> Emp Id:{emp.empId}</h2>
            <h2> Emp Name:{emp.empName}</h2>
            <h2> Salary:{emp.salary}</h2>
            <input type="button" value="Increment salary" onClick={incrementSalaryEventHandler}/>
            <input type="button" value="Increment" onClick={incrementEventHandler}/>
            
        </div>
    
    )
}
export default Footer;

/*
Destructuring an array -- ES6
var arr1=[10,20,30,40,50];
var i,j=20;
clg(i);//ud
clg(j);//20

var [first,second]=arr1;
clg(first);//10
clg(second);//20

var [first,,third]=arr1;
clg(first);//10
clg(third);//30

var myInfo=[101,"sara","d1",5678];

function useMyFunc(p1)
{
    function setFunction(s1){p1=s1;}
    var returnArr=[p1,setFunction];
    return (returnArr)
}


*/