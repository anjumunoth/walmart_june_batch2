import React, { Component } from 'react'
import AddToCart from "./AddToCart";

export default class Products extends Component {
    // productsArr -- dynamic; size dynamic
    
    constructor()
    {
        super();
        this.state={
            showAddToCart:false,
            selectedProduct:{},
            productsArr :[
                { productId: "P101", name: "Iphone", price: 145678, quantity: 10, description: "Apple Iphone 13 Pro max", imgUrl: "./images/iphone.jpg", specs:{memory:"256gb",RAM:"16gb"} },
                { productId: "P102", name: "Samsung note9", price: 125678, quantity: 5, description: "Samsung note 9 256gb", imgUrl: "./images/samsung.jpg", specs:{memory:"256gb",RAM:"16gb"}  },
                { productId: "P103", name: "One plus9", price: 45678, quantity: 7, description: "One plus 9 512gb", imgUrl: "./images/oneplus9.jpg", specs:{memory:"256gb",RAM:"16gb"}  },
                { productId: "P104", name: "Nokia", price: 1456, quantity: 2, description: "Nokia ", imgUrl: "./images/nokia.jpg" , specs:{memory:"256gb",RAM:"16gb"} }
            ]
        };
        
        this.detailsEventHandler=this.detailsEventHandler.bind(this);
    }

    addToCartEventHandler=(selectedProduct)=>{
        // FAF; this --> lexical scope ; outer scope; class
        console.log("Inside the add to cart event handler",selectedProduct);
        console.log("products arr in FAF",this.productsArr);// will work
        //this.showAddToCart=true;
        this.setState(
            {showAddToCart:true, selectedProduct:selectedProduct},
            ()=>{
                console.log("Show Add To cart"+ this.state.showAddToCart);//true
            }
            );
        //alert("Show Add To cart"+ this.state.showAddToCart);//false
        // return the new virtual DOM with the changes
        // call the render method again
    }
    detailsEventHandler(selectedProduct){
        // anonymous function
        // this-- undefined
        console.log("Inside the details event handler",selectedProduct);
        console.log("products arr in Anonymous function",this.productsArr);// will not work
    }
    onCancelConfirmationEventHandler=()=>{
        this.setState({showAddToCart:false});
    }
    onBuyConfirmationEventHandler=(cartObj)=>{
        this.setState({showAddToCart:false});
        console.log("Cart Obj in Products Component",cartObj);
        // reduce the quantity of that particular product;
        // traverse the state.productsArr
        // cartObj={productId:P103,quantity:7,quantitySelected:2}
        // pos=2;
        //productToUpdate= { productId: "P103", name: "One plus9", price: 45678, quantity: 7, description: "One plus 9 512gb", imgUrl: "./images/oneplus9.jpg", specs:{memory:"256gb",RAM:"16gb"}  },
        //productToUpdate= { productId: "P103", name: "One plus9", price: 45678, quantity: 5, description: "One plus 9 512gb", imgUrl: "./images/oneplus9.jpg", specs:{memory:"256gb",RAM:"16gb"}  },
        //tempProductsArr is a copy of productsArr

        /*
        var pos= this.state.productsArr.findIndex(item => item.productId === cartObj.productId);
        var productToUpdate={...this.state.productsArr[pos]};
        productToUpdate.quantity-=cartObj.quantitySelected;
        var tempProductsArr=[...this.state.productsArr];
        tempProductsArr.splice(pos,1,productToUpdate);
        */

        var tempProductsArr=[...this.state.productsArr];
        var pos= tempProductsArr.findIndex(item => item.productId === cartObj.productId);
        tempProductsArr[pos].quantity-=cartObj.quantitySelected;

        this.setState({productsArr:tempProductsArr});

        this.props.onsendCartFromProductsToHome(cartObj);


    }
    render() {
        // dynamic generation of contents
        var cardsArr= this.state.productsArr.map(item =>
            {
                return (
                    <div key={item.productId} className='col-4'>
                        <div className='card'>
                            <img className='card-img-top img-responsive' src={item.imgUrl} alt={item.name} />
                            <div className='card-body'>
                                <h1 className='card-title'>{item.name}</h1>
                                <p className='card-text'>Price : {item.price}</p>
                                <p className='card-text'>Quantity : {item.quantity}</p>
                                <p className='card-text'>Memory: {item.specs.memory}</p>
                                <p className='card-text'>RAM: {item.specs.RAM}</p>
                                <p className='card-text'>Specification:  {JSON.stringify(item.specs)}</p>
                                <input type="button" value="Add To Cart" className='btn btn-primary m-2' 
                                    onClick={this.addToCartEventHandler.bind(this,item)}/>
                                <input type="button" value="Details" className='btn btn-primary m-2' 
                                    onClick={()=>{ 
                                    this.detailsEventHandler(item);
                                }}/>
                            </div>
                        </div>
                    </div>
                );
            });

        return (
            <div className='container-fluid'>
                <div className='row'>
                    {cardsArr}
                </div>
                {
                this.state.showAddToCart && 
                    <AddToCart 
                        selectedProd={this.state.selectedProduct}
                        
                        onCancelConfirmation={this.onCancelConfirmationEventHandler}
                        onBuyConfirmation={this.onBuyConfirmationEventHandler}
                        ></AddToCart>}

            </div>
        )
    }
}

/*
In jsx
-- no loops
-- no if-esle; switch;

In ES6
map method 

Java :
class Emp{
    int empId;
    string empName;
    // overridden toString
}
var sara=new Emp();
sara.empId=101;
sara.empName="sara";
SOP(sara);// objectId

Strict mode --
-- useful in development phase
deprecated function -- warnings

Conditional rendering of Component
--if else; switch -- Not allowed in JSX
-- logical and &&( first condition is false, will not check the second condition); ternary operator ?:


i=10;
SOP(i);// 10
i=20;

constructor
-- initialise the variables
-- create the object, constructor gets called
-- always gets called implicitly
-- first function to be called when the object is created
-- can be called only once 
-- first lifecycle method


render method
-- called implicitly
-- after the constructor
-- lifecycle method 
-- state of a component -- set the state -- call the render implicitly 


state
-- local mutable of a particular component
-- object
-- initialise it in the constructor
-- change the state -- calling the setState()
-- change the state using state.fieldName=newValue;-- Not

setState()
-- 2 params
-- first param -- object/ function
-- second param -- call back function
-- update the state and call the render method impliictly
-- first param -- object -- merged with the current state
-- first param -- function -- single param -- current state; return a new object which will be merged with a state

-- second param -- when setState has completed the operation; second param function is executed
-- setState is an asynchronous function call
-- 

update emp set salary=1000 where empId=101;
update emp set salary=salary +1000 where empId=102

send data from parent from to child -- properties/attributes

<a href="https://wwww.walmary.com">Go to Walmart<a>

var arr1=[10,20,30];
var arr2=[...arr1,20];
clg(arr2);//[10,20,30,20]


var arr=[10,20,30,40,50];

arr.splice(position, number of elements to delete, element to be inserted, element to be inserted)

arr.splice(1,2);
clg(arr);[10,40,50]

arr=[10,20,30,40,50];
arr.splice(2,1);
clg(arr);[10,20,40,50]

arr=[10,20,30,40,50];
arr.splice(2,1,22,33);
clg(arr);[10,20,22,33,40,50]

arr=[10,20,30,40,50];
arr.splice(2,0,22,33);
clg(arr);[10,20,22,33,30,40,50]


Higher order components

function f1(p1,p2)
{
    return p1+p2;
}

function addTwoStrings(p1,p2)
{
    return f1(p1,p2)
}

function addTwoNumbers(p1,p2)
{
    return f1(p1,p2)
}

function addTwoSalaries(emp1,emp2)
{
    return f1(emp1.salary,emp2.salary);
}

Component:QuantityManage

AddToCart: selectedQuantity : + -

Cart : updatedQuantity : Increment ; Decrement

HOC(fieldName,but1Name,but2Name)
return 
{
    <QuantityManage fieldName,but1Name,but2Name>
}

AddToCart
<HOC selectedQuantity + ->

Cart
<HOC updatedQuantity Increment Decrement >

<Hoc>
<App >











*/
