import React from 'react';

class Footer extends React.Component
{
    render()
    {
        return (
            <div>
                <h1> Footer Component</h1>
            </div>
        )
    }
}

export default Footer;