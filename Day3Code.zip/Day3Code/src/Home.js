import React, { Component } from 'react'
import Products from './Products';
import Cart from "./Cart"

export default class Home extends Component {
    constructor() {
        super();
        this.state = { showProducts: true,cartObj:{} }
    }
    onsendCartFromProductsToHomeEventHandler=(cartObj)=>{
        this.setState({cartObj:cartObj})
    }
    render() {
        return (
            <div>


                {
                    this.state.showProducts
                        ?
                        <div>
                            <input type="button" value="Cart" className='btn btn-primary' onClick={()=>{
                                this.setState({showProducts:false})
                            }} />
                            <Products onsendCartFromProductsToHome={this.onsendCartFromProductsToHomeEventHandler}></Products>
                        </div>
                        :
                        <div>
                            <input type="button" value="Products" className='btn btn-primary' onClick={()=>{
                                this.setState({showProducts:true})
                            }} />
                            <Cart cartObj={this.state.cartObj}></Cart>
                        </div>
                }

            </div>
        )
    }
}
