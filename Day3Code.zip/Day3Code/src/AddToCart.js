import React, { Component } from 'react'
import PropTypes from "prop-types";

export default class AddToCart extends Component {
    constructor(props) {
        super(props);
        this.state = { quantitySelected: 1 }
        
    }
    changeQuantityEventHandler = (strOp) => {
        if (strOp === "dec") {
            //this.setState({quantitySelected:this.state.quantitySelected-1});
            // logically right
            if (this.state.quantitySelected > 1) {
                this.setState((prevState) => {
                    return ({
                        quantitySelected: prevState.quantitySelected - 1
                    })
                })
            }
        }
        else {
            if (this.state.quantitySelected < this.props.selectedProd.quantity) {
                this.setState((prevState) => {
                    return ({
                        quantitySelected: prevState.quantitySelected + 1
                    })
                })
            }
        }
    }
    cancelEventHandler = () => {
        //trigger the event in the parent
        this.props.onCancelConfirmation();
    }
    buyEventHandler = () => {
        var cartObj = { ...this.props.selectedProd, quantitySelected: this.state.quantitySelected };
        // cartObj -- send to Products
        this.props.onBuyConfirmation(cartObj);
    }
    render() {
        console.log("Props in AddToCart", this.props);
        var item = this.props.selectedProd;
        return (
            <div className='container-fluid'>AddToCart Component
                <div className='row'>
                    <h1 className='col-4 offset-4'>  {this.props.companyName}</h1>
                </div>
                
                {Object.keys(this.props.selectedProd).length===0 
                    ? <h1>Product Details not available</h1>
                    :
                    <div className='row'>

                        <div className='col-3 bg-primary offset-4'>
                            <div className='card bg-primary text-white' >
                                <img className='card-img-top img-responsive' src={item.imgUrl} alt={item.name} />
                                <div className='card-body'>
                                    <h1 className='card-title'>{item.name}</h1>
                                    <p className='card-text'>Price : {item.price}</p>
                                    <p className='card-text'>Quantity : {item.quantity}</p>
                                    <p className='card-text'>Memory: {item?.specs?.memory}</p>
                                    <p className='card-text'>RAM: {item?.specs?.RAM}</p>
                                    <p className='card-text'>Specification:  {JSON.stringify(item.specs)}</p>
                                    <input type="button" value="-" className='btn btn-warning m-2'
                                        disabled={this.state.quantitySelected <= 1}
                                        onClick={this.changeQuantityEventHandler.bind(this, "dec")} />
                                    <span>{this.state.quantitySelected}</span>
                                    <input type="button" value="+" className='btn btn-warning m-2'
                                        disabled={this.state.quantitySelected >= this.props.selectedProd.quantity}
                                        onClick={() => { this.changeQuantityEventHandler("inc") }} />

                                    <br />
                                    <input type="button" value="Buy" className='btn btn-success m-2' onClick={this.buyEventHandler} />
                                    <input type="button" value="Cancel" className='btn btn-danger m-2' onClick={this.cancelEventHandler} />
                                </div>
                            </div>
                        </div>
                    </div>
                }
            </div>
        )

    }
}

AddToCart.propTypes = {
    companyName: PropTypes.string.isRequired,
    selectedProd:PropTypes.object

    
}
AddToCart.defaultProps = {
    companyName: "Walmart",
    selectedProd: {}
}
/*
send data from child to parent

Component A
<input type="button" value="Click" onClick={this.clickEventHandler} />

-- clickEventHandler -- will be written in Component A
-- trigger the event -- user clicks on the button
-- input tag -- component A

Products , Add To cart
In Products 
<AddToCart companyName="walmart" onClick={this.clickEventHandler} ></AddToCart>

-- clickEventHandler -- will be written in Products
-- Instance of AddToCart is created in Products
-- trigger the event OnClick -- AddToCart will trigger it
-- this.props.onClick(); triggering the event
-- this.props.companyName

Prop type checking -- happens only during development not during production
Interfaces -- adhering to the interface -- error  -- even in production phase

*/