import React from "react";

class Header extends React.Component
{
    render()
    {
        // return the virtual DOM
        return (
            <div className='container-fluid bg-primary'>
            <div className='row align-items-center'>
              <img className='col-3' style={{height:"150px"}} src="./logo192.png" alt="Logo of react" />
              <h1 className='col-9 text-center' style={{color:"cyan",fontSize:"36px"}}>React</h1>
            </div>
          
          </div>
        );
    }
}

export default Header;