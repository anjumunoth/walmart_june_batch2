import React, { Component } from 'react';
import axios from 'axios';

export default class Users extends Component {
    constructor()
    {
        super();
        this.state={usersArr:[]};
    }
componentDidMount()
{
    // after the first render and DOm has been loaded, this function will be called
    // will be called once during the lifetime of component
    // axios -- AJAX request 
    var serverUrl="https://jsonplaceholder.typicode.com/users";
    axios.get(serverUrl)
    .then((response)=>{
        console.log("Response",response);
        // status code; headers info; data; 
        this.setState({usersArr:response.data});
    })
    .catch((err)=>{
        console.log("Error",err);
    })
}
  render() {
    var trArr=this.state.usersArr.map(item=>{
        return (
            <tr key={item.id}>
                <td>{item.name}</td>
                <td>{item.email}</td>
                <td>{item.address.city}</td>
            </tr>
        )
    })
    return (
      <div>
        <h1>User Component</h1>
        {this.state.usersArr.length ==0 
        ?
        <h1>Loading ...</h1>
        :
        <table className='table'>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>City</th>
                </tr>
            </thead>
            <tbody>
            {trArr}
            </tbody>
        </table>
        }
      </div>
    )
  }
}


//npm install --save axios
//constructor -- call to the server-- BAD
/*
constructor -- call to the server
render -- map to Real DOM
first data will be fetched and the page will be loaded
Bad practice

Ideal situation:
constructor
render
fetch the data -- after the page loads; should be a one time process




*/

