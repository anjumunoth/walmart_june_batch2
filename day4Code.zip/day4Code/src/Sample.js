import React,{useEffect} from 'react'

function Sample()
{
    useEffect(()=>{
        alert("Inside the useEffect of Sample")
        return (()=>{
            // can work with state but of no use
            alert("sample component also will get unmounted");
        })
    },[])
    return (
        <h1>Sample Component</h1>
    )
}

export default Sample;