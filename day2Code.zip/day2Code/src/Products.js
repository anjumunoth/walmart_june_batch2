import React, { Component } from 'react'

export default class Products extends Component {
    // productsArr -- dynamic; size dynamic
    productsArr = [
        { productId: "P101", name: "Iphone", price: 145678, quantity: 10, description: "Apple Iphone 13 Pro max", imgUrl: "./images/iphone.jpg", specs:{memory:"256gb",RAM:"16gb"} },
        { productId: "P102", name: "Samsung note9", price: 125678, quantity: 5, description: "Samsung note 9 256gb", imgUrl: "./images/samsung.jpg", specs:{memory:"256gb",RAM:"16gb"}  },
        { productId: "P103", name: "One plus9", price: 45678, quantity: 7, description: "One plus 9 512gb", imgUrl: "./images/oneplus9.jpg", specs:{memory:"256gb",RAM:"16gb"}  },
        { productId: "P104", name: "Nokia", price: 1456, quantity: 2, description: "Nokia ", imgUrl: "./images/nokia.jpg" , specs:{memory:"256gb",RAM:"16gb"} }
    ];
    constructor()
    {
        super();
        this.detailsEventHandler=this.detailsEventHandler.bind(this);
    }

    addToCartEventHandler=(selectedProduct)=>{
        // FAF; this --> lexical scope ; outer scope; class
        console.log("Inside the add to cart event handler",selectedProduct);
        console.log("products arr in FAF",this.productsArr);// will work
    }
    detailsEventHandler(){
        // anonymous function
        // this-- undefined
        console.log("Inside the details event handler");
        console.log("products arr in Anonymous function",this.productsArr);// will not work
    }
    render() {
        // dynamic generation of contents
        var cardsArr= this.productsArr.map(item =>
            {
                return (
                    <div key={item.productId} className='col-4'>
                        <div className='card'>
                            <img className='card-img-top img-responsive' src={item.imgUrl} alt={item.name} />
                            <div className='card-body'>
                                <h1 className='card-title'>{item.name}</h1>
                                <p className='card-text'>Price : {item.price}</p>
                                <p className='card-text'>Quantity : {item.quantity}</p>
                                <p className='card-text'>Memory: {item.specs.memory}</p>
                                <p className='card-text'>RAM: {item.specs.RAM}</p>
                                <p className='card-text'>Specification:  {JSON.stringify(item.specs)}</p>
                                <input type="button" value="Add To Cart" className='btn btn-primary m-2' onClick={this.addToCartEventHandler.bind(this,item)}/>
                                <input type="button" value="Details" className='btn btn-primary m-2' onClick={this.detailsEventHandler}/>
                            </div>
                        </div>
                    </div>
                );
            });

        return (
            <div className='container-fluid'>
                <div className='row'>
                    {cardsArr}
                </div>

            </div>
        )
    }
}

/*
In jsx
-- no loops
-- no if-esle; switch;

In ES6
map method 

Java :
class Emp{
    int empId;
    string empName;
    // overridden toString
}
var sara=new Emp();
sara.empId=101;
sara.empName="sara";
SOP(sara);// objectId

Strict mode --
-- useful in development phase
deprecated function -- warnings

*/
